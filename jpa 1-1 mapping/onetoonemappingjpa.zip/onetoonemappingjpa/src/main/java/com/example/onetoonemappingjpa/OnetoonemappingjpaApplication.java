package com.example.onetoonemappingjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetoonemappingjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetoonemappingjpaApplication.class, args);
	}

}
