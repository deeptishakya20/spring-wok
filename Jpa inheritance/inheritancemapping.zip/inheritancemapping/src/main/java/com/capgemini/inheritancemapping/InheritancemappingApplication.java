package com.capgemini.inheritancemapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InheritancemappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(InheritancemappingApplication.class, args);
	}

}
