package com.capgemini.jpasimplemapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpasimplemappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpasimplemappingApplication.class, args);
	}

}
